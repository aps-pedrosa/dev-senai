#include <stdio.h>

void ex40() {
  printf("Numeros: \n");
  for (int i = 120; i < 301; i++) {
    printf("%d\n", i);
  }
}
