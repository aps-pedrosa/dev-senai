#include <stdio.h>

void ex38() {
  printf("Numeros: \n");
  for (int i = 100; i > 0; i--) {
    printf("%d\n", i);
  }
}
