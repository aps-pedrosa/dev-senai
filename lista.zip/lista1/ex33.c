#include <stdio.h>

void ex33() {

float a, b, c, delta, x1, x2;

    printf("Digite o valor da A: ");
    scanf("%f", &a);

    printf("Digite o valor de B: ");
    scanf("");
}
