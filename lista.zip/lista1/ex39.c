#include <stdio.h>

void ex39() {
  printf("Múltiplos de 5 entre 1 e 500: \n");
  for (int i = 5; i <= 500; i += 5) {
    printf("%d\n", i);
  }
}
